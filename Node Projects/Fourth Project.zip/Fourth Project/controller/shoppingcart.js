const generateUniqueId = require('generate-unique-id');
const knex=require('../model/database')
// const id = generateUniqueId(req.body.cart_id)




get_generateUniqueId=(req,res)=>{
    knex.select('*').from('shopping_cart')
    .then((cartUnique)=>{
        cartUnique = generateUniqueId({
            includeSymbols: ['@','#','|'],
            excludeSymbols: ['0']
          });
        res.send({
            message:'Get Unique Id',
            cart_id:cartUnique})
    }).catch((err)=>{
        res.send({message:'Something went wrong'})
    })

}



// Add a product in the card
product_addCart_post=(req,res)=>{
    const addProductCar={
        cart_id:req.body.cart_id,
        product_id:req.body.product_id,
        attributes:req.body.attributes
    }
    console.log(addProductCar);
    knex('shopping_cart').insert(addProductCar)
    // .join('product','shopping_cart.product_id','product.product_id')
    .select('*')
    .then((addCartProduct)=>{
        res.json({
            succes:true,
            message:'Add a Product in the cart succesfully!',
            AddCart:addCartProduct

        })

    }).catch((err)=>{
        console.log(err)
        res.json({
            error:'addCard failed'
        })
    })
  

}





// Update the cart by item
updateCartByItem=(req,res)=>{
    knex('shopping_cart').where('item_id',req.params.item_id).update({
        quantity:req.body.quantity
    })
    .then((data)=>{
        knex.select('*').from('shopping_cart').where('item_id',data)
        .then((quantity)=>{
            if (quantity.length===0){
                res.send({message:'You dont have item'})
            }else{
                res.json({
                    succes:true,
                    message:'Update the cart by item',
                    UpdateCart_byItem:quantity
                    
                })

            }
            
        }).catch((err)=>{
            res.json({
                message:'Update the cart by item failed'
            })
        })
    }).catch((err)=>{
        res.json({
            message:'Not Found Item Id'
        })
    })

}
















module.exports={get_generateUniqueId,product_addCart_post,updateCartByItem}