const knex=require('../model/database')





// Create Order booking 
postOrders=(req,res)=>{
    const order={
        cart_id:req.body.cart_id,
        shipping_id:req.body.shipping_id,
        tax_id:req.body.tax_id

    }
    knex('orders').insert(order)
    .then((data)=>{
        knex.select('*').where('order_id',data)
        .then((postorder)=>{
            res.status(200).json({
                message:'Order added',
                order:postorder
            })

        }).catch((err)=>{
            res.status(405).json({
                message:'Order Failed'
            })
        })
           
    
    }).catch((err)=>{
        console.log(err)
        res.status(400).json({
            message:'Something went wrong'
        })
    })

}





// Get order data by order id
getOrder_ById=(req,res)=>{
    knex.select('*').from('orders').where('order_id ',req.params.order_id )
    .then((getOrder)=>{
        res.json({
            sussec:true,
            message:'Order by order_id ',
            orders:getOrder
        })
    }).catch((err)=>{
            res.status(400).json({
            message:'Order Id Invalid'
        })

    })
}






// Get order by customer id
getOrder_customerId=(req,res)=>{
    knex('orders')
    join('customer','orders.customer_id','customer.customer_id')
    .select('*').where('customer.customer_id',req.param.customer_id)
    .then((getByCustomer)=>{
        res.json({
            succes:true,
            message:'Order By Customer Id',
            orderCustomer:getByCustomer
        })
    }).catch((err)=>{
        res.json({
            message:'User not exits'
        })
    })

}














module.exports={postOrders,getOrder_ById,getOrder_customerId}